$title Laboratory 8 - variant 3 - NLP, 20 editable scenarios, three starts
$onText
Original variables q in tons/day; revenue z in million RUB/day for scaling.
Base price p0 and input a0 are defined at q0=100 tons/day.
Extra product in this task is yogurt, on cream's shared line.
Edit ../data/scenarios.csv, run ../scripts/prepare_data.py, then this model.
An equivalent convex problem in raw-input variables is also solved.
Independent supporting-tangent certificates are in the Python verifier.
$offText
Set j /milk,kefir,cream,yogurt/, st /start1*start3/;
$include scenarios.inc
Parameter a0(j) /milk 1.01,kefir 1.01,cream 9.45,yogurt .9/,
 ep(j) /milk -.033,kefir -.034,cream -.060,yogurt -.051/,
 ea(j) /milk -.020,kefir -.012,cream -.019,yogurt -.014/,
 lower(j) /milk 25,kefir 30,cream 1.5,yogurt 1/,
 initial(j) /milk 300,kefir 500,cream 30,yogurt 5/,
 p0(j),pcol(j,*), rep(s,*),starts(s,st,*);
Scalar available,tm,ts,violation,best,spread;
Positive Variables q(j),t(j);
Variable z;
Equations obj,raw,mk,cy,cobj,craw,cmk,ccy;
obj.. z =e= sum(j,p0(j)*100*rPower(q(j)/100,1+ep(j)))/1e6;
raw.. sum(j,a0(j)*100*rPower(q(j)/100,1+ea(j))) =l= available;
mk.. q('milk')/50+q('kefir')/60 =l= tm;
cy.. q('cream')/3+q('yogurt')/2 =l= ts;
cobj.. z =e= sum(j,p0(j)*100*rPower(t(j)/a0(j),(1+ep(j))/(1+ea(j))))/1e6;
craw.. sum(j,100*t(j)) =l= available;
cmk.. 100*rPower(t('milk')/a0('milk'),1/(1+ea('milk')))/50
     +100*rPower(t('kefir')/a0('kefir'),1/(1+ea('kefir')))/60 =l= tm;
ccy.. 100*rPower(t('cream')/a0('cream'),1/(1+ea('cream')))/3
     +100*rPower(t('yogurt')/a0('yogurt'),1/(1+ea('yogurt')))/2 =l= ts;
Model original /obj,raw,mk,cy/,convex /cobj,craw,cmk,ccy/;
option nlp=conopt,limrow=0,limcol=0,optcr=1e-9,optca=1e-9,reslim=60;
q.lo(j)=lower(j);
loop(s,
 available=cond(s,'raw_t'); tm=cond(s,'mk_hours'); ts=cond(s,'cy_hours');
 p0('milk')=cond(s,'p_milk');p0('kefir')=cond(s,'p_kefir');
 p0('cream')=cond(s,'p_cream');p0('yogurt')=cond(s,'p_yogurt');
 q.up('milk')=50*tm;q.up('kefir')=60*tm;
 q.up('cream')=3*ts;q.up('yogurt')=2*ts;
 best=-inf;
 loop(st,
  q.l(j)=lower(j)+(0.2+0.3*(ord(st)-1))*(initial(j)-lower(j));
  q.m(j)=0; z.l=0; z.m=0;
  solve original using nlp maximizing z;
  abort$((original.modelstat<>1 and original.modelstat<>2) or original.solvestat<>1) 'NLP failed',s,st;
  violation=max(0,sum(j,a0(j)*100*rPower(q.l(j)/100,1+ea(j)))-available,
   q.l('milk')/50+q.l('kefir')/60-tm,q.l('cream')/3+q.l('yogurt')/2-ts,
   smax(j,lower(j)-q.l(j)));
  abort$(violation>1e-5) 'NLP infeasible',s,st,violation;
  starts(s,st,'obj')=z.l*1e6;
  starts(s,st,'modelstat')=original.modelstat;starts(s,st,'solvestat')=original.solvestat;
  starts(s,st,'violation')=violation;
  loop(j,starts(s,st,j)=q.l(j););
  if(z.l>best,
   best=z.l;loop(j,rep(s,j)=q.l(j););
   rep(s,'obj')=z.l*1e6;
   rep(s,'modelstat')=original.modelstat;rep(s,'solvestat')=original.solvestat;
   rep(s,'raw_shadow')=raw.m*1e6;rep(s,'mk_shadow')=mk.m*1e6;rep(s,'cy_shadow')=cy.m*1e6;
  );
 );
 spread=(smax(st,starts(s,st,'obj'))-smin(st,starts(s,st,'obj')))/rep(s,'obj');
 abort$(spread>.001) 'More than 0.1 percent start spread',s,spread;
 rep(s,'spread')=spread;
 t.lo(j)=a0(j)*rPower(lower(j)/100,1+ea(j));
 t.up(j)=a0(j)*rPower(q.up(j)/100,1+ea(j));
 t.l(j)=a0(j)*rPower(rep(s,j)/100,1+ea(j));
 solve convex using nlp maximizing z;
 abort$((convex.modelstat<>1 and convex.modelstat<>2) or convex.solvestat<>1) 'Transformed NLP failed',s;
 rep(s,'convex_obj')=z.l*1e6;
 rep(s,'convex_modelstat')=convex.modelstat;rep(s,'convex_solvestat')=convex.solvestat;
 abort$(abs(rep(s,'obj')-rep(s,'convex_obj'))/rep(s,'obj')>1e-6) 'Transformed objective mismatch',s;
);
File f /'../results/lab8_gams_scenarios.csv'/;
f.pw=32767;
put f 'scenario_id,raw_t,mk_hours,cy_hours,p_milk,p_kefir,p_cream,p_yogurt,q_milk,q_kefir,q_cream,q_yogurt,objective_rub,modelstat,solvestat,start_spread_relative,convex_objective_rub,convex_modelstat,convex_solvestat,shadow_raw,shadow_mk,shadow_cy,status' /;
loop(s,
 put s.tl:0 ',' cond(s,'raw_t'):0:8 ',' cond(s,'mk_hours'):0:8 ',' cond(s,'cy_hours'):0:8 ',';
 put cond(s,'p_milk'):0:8 ',' cond(s,'p_kefir'):0:8 ',' cond(s,'p_cream'):0:8 ',' cond(s,'p_yogurt'):0:8 ',';
 loop(j,put rep(s,j):0:10 ',';);
 put rep(s,'obj'):0:10 ',' rep(s,'modelstat'):0:0 ',' rep(s,'solvestat'):0:0 ',' rep(s,'spread'):0:12 ',';
 put rep(s,'convex_obj'):0:10 ',' rep(s,'convex_modelstat'):0:0 ',' rep(s,'convex_solvestat'):0:0 ',';
 put rep(s,'raw_shadow'):0:8 ',' rep(s,'mk_shadow'):0:8 ',' rep(s,'cy_shadow'):0:8 ',OPTIMUM_FOUND' /;
);putclose f;
File h /'../results/lab8_gams_starts.csv'/;
h.pw=32767;
put h 'scenario_id,start_id,q_milk,q_kefir,q_cream,q_yogurt,objective_rub,modelstat,solvestat,max_violation' /;
loop((s,st),put s.tl:0 ',' st.tl:0 ',';loop(j,put starts(s,st,j):0:10 ',';);
 put starts(s,st,'obj'):0:10 ',' starts(s,st,'modelstat'):0:0 ',' starts(s,st,'solvestat'):0:0 ',' starts(s,st,'violation'):0:10 /;
);putclose h;
display rep;
