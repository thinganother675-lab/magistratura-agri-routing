$title Laboratory 10 - variant 3 - output-oriented VRS DEA for 25 firms
$onText
Max phi with resource limits, expanded outputs, nonnegative intensities
and sum(lambda)=1. Report efficiency k=1/phi. Zero y2 of firm9 retained.
Output scale /1000 improves conditioning and changes neither phi nor k.
Official model-library dea.gms is a structural reference; its input
orientation is not silently substituted for the course's output model.
$offText
Sets i /f1*f25/,m /lawyers,economists/,r /legal,reengineering/;
Alias(i,j);
$include dea-data.inc
Parameter x(i,m),y(i,r),xref(m),yref(r),report(i,*),peers(i,j);
x(i,'lawyers')=d(i,'x1');x(i,'economists')=d(i,'x2');
y(i,'legal')=d(i,'y1')/1000;y(i,'reengineering')=d(i,'y2')/1000;
Positive Variable intensity(j);
Variable phi;
phi.lo=1;
Equations inputs(m),outputs(r),convexity;
inputs(m).. sum(j,x(j,m)*intensity(j)) =l= xref(m);
outputs(r).. sum(j,y(j,r)*intensity(j)) =g= phi*yref(r);
convexity.. sum(j,intensity(j)) =e= 1;
Model dea /all/;
option lp=cplex,limrow=0,limcol=0;
Scalar violation;
loop(i,
 xref(m)=x(i,m);yref(r)=y(i,r);
 intensity.l(j)=0;intensity.l(i)=1;phi.l=1;
 solve dea using lp maximizing phi;
 abort$(dea.modelstat<>1 or dea.solvestat<>1) 'DEA failed',i;
 violation=max(0,smax(m,sum(j,x(j,m)*intensity.l(j))-xref(m)),
  smax(r,phi.l*yref(r)-sum(j,y(j,r)*intensity.l(j))),
  abs(sum(j,intensity.l(j))-1),-smin(j,intensity.l(j)));
 abort$(violation>1e-7 or phi.l<1-1e-8) 'DEA invalid',i,violation;
 report(i,'phi')=phi.l;report(i,'k')=1/phi.l;
 report(i,'modelstat')=dea.modelstat;report(i,'solvestat')=dea.solvestat;
 report(i,'violation')=violation;peers(i,j)=intensity.l(j);
);
File f /'../results/lab10_gams_dea.csv'/;
put f 'firm,phi,efficiency,modelstat,solvestat,max_violation' /;
loop(i,put ord(i):0:0 ',' report(i,'phi'):0:12 ',' report(i,'k'):0:12 ',' report(i,'modelstat'):0:0 ',' report(i,'solvestat'):0:0 ',' report(i,'violation'):0:12 /;);
putclose f;
File g /'../results/lab10_gams_peers.csv'/;
put g 'firm,peer,weight' /;
loop((i,j)$(peers(i,j)>1e-8),put ord(i):0:0 ',' ord(j):0:0 ',' peers(i,j):0:12 /;);
putclose g;
display report;
