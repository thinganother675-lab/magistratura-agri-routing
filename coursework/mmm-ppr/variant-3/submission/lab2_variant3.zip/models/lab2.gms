$title Laboratory 2 - variant 3 - milk production LP
$onText
Draft calculation prepared at student's request, pending teacher's prior
approval of the mathematical formulation required by the course.
Units: centners/day, hours/day, RUB/day. Extra product: curd bars.
Run from this directory: gams lab2.gms
$offText
Set j /milk,kefir,cream,curd_bars/;
Parameter price(j) /milk 2400,kefir 2700,cream 13800,curd_bars 7200/,
          input(j) /milk 1.01,kefir 1.01,cream 9.45,curd_bars 15/;
Positive Variable x(j);
Variable revenue;
Equations objective,raw,mkLine,creamLine,curdLine;
objective.. revenue =e= sum(j,price(j)*x(j));
raw.. sum(j,input(j)*x(j)) =l= 140;
mkLine.. x('milk')/5+x('kefir')/6 =l= 21;
creamLine.. x('cream')/0.3 =l= 16;
curdLine.. x('curd_bars')/0.2 =l= 16;
Model production /all/;
option lp=cplex,limrow=0,limcol=0;
solve production using lp maximizing revenue;
abort$(production.modelstat<>1 or production.solvestat<>1) 'LP failed';
Scalar violation;
violation=max(0,sum(j,input(j)*x.l(j))-140,
 x.l('milk')/5+x.l('kefir')/6-21,x.l('cream')/.3-16,
 x.l('curd_bars')/.2-16,-smin(j,x.l(j)));
abort$(violation>1e-7) 'Infeasible LP output',violation;
File f /'../results/lab2_gams.csv'/;
f.pw=32767;
put f 'product,x_centner,revenue_rub,modelstat,solvestat' /;
loop(j,put j.tl:0 ',' x.l(j):0:10 ',' revenue.l:0:10 ',' production.modelstat:0:0 ',' production.solvestat:0:0 /;);
putclose f;
File g /'../results/lab2_gams_resources.csv'/;
put g 'resource,used,available,shadow_price' /;
put 'raw,' sum(j,input(j)*x.l(j)):0:10 ',140,' raw.m:0:10 /;
put 'milk_kefir_hours,' (x.l('milk')/5+x.l('kefir')/6):0:10 ',21,' mkLine.m:0:10 /;
put 'cream_hours,' (x.l('cream')/.3):0:10 ',16,' creamLine.m:0:10 /;
put 'curd_hours,' (x.l('curd_bars')/.2):0:10 ',16,' curdLine.m:0:10 /;
putclose g;
display x.l,revenue.l,raw.m,mkLine.m,creamLine.m,curdLine.m;
