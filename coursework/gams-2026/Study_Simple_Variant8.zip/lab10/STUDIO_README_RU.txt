GAMS Studio
1. Открыть lab10.gms и выбрать эту папку как рабочий каталог.
2. Запустить F9. Требуется решатель CPLEX.
3. В lab10.lst проверить 25 секций решения: SOLVER STATUS 1, MODEL STATUS 1.
4. efficiencies.csv содержит phi, E=1/phi и статусы. peers.csv содержит все веса эталонных фирм, включая нули.
5. После завершения F9 запустить 04_RECALCULATE_STATS.cmd. Статистика читает input_data.csv и efficiencies.csv фактического запуска, проверяет порядок фирм. До запуска статистики сохранить изменения модели и обязательно выполнить F9. 03_OPEN_GAMS.cmd открывает модель в GAMS Studio на этом ПК.
6. Статистика рассчитана отдельно в Python по разрешённому заданием инструменту. spearman.csv содержит обе проверки; ranks.csv позволяет повторить анализ средних рангов в Excel. Скрипт воспроизведения находится в tmp/gams-simple-tools/statistics_simple.py относительно корня проекта, вне папок GAMS. Зависимости scipy/numpy берутся из существующего runtime/python_packages варианта 11 без изменения старых файлов.
Команда GAMS: gams lab10.gms lo=3
Проверка: independent-check.csv и verification.json. Эти файлы не заменяют основное решение GAMS.

